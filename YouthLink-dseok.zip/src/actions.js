import { HttpError } from 'wasp/server'

export const createMessage = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  const newMessage = await context.entities.Message.create({
    data: {
      content: args.content,
      sender: { connect: { id: context.user.id } },
      recipient: { connect: { id: args.recipientId } }
    }
  });

  return newMessage;
}

export const deleteMessage = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  const message = await context.entities.Message.findUnique({
    where: { id: args.messageId }
  });
  if (message.recipientId !== context.user.id && message.senderId !== context.user.id) { throw new HttpError(403) };
  return context.entities.Message.delete({
    where: { id: args.messageId }
  });
}