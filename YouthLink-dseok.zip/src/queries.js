import { HttpError } from 'wasp/server'

export const getMessages = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Message.findMany({
    where: {
      OR: [
        { senderId: context.user.id },
        { recipientId: context.user.id }
      ]
    }
  })
}

export const getUserMentors = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.Mentors.findMany({
    where: {
      userId: context.user.id
    },
    include: {
      user: true
    }
  })
}