import React from 'react';
import { Link } from 'wasp/client/router';
import { useQuery, getUserMentors } from 'wasp/client/operations';

const MentorsListPage = () => {
  const { data: mentors, isLoading, error } = useQuery(getUserMentors);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      {mentors.map((mentor) => (
        <div key={mentor.id} className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'>
          <div>{mentor.user.username}</div>
          <div>Mentor</div>
        </div>
      ))}
    </div>
  );
}

export default MentorsListPage;