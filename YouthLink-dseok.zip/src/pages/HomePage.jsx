import React from 'react';
import { Link } from 'wasp/client/router';
import { useQuery, useAction, getMessages } from 'wasp/client/operations';
const HomePage = () => {
  const { data: messages, isLoading, error } = useQuery(getMessages);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <h1 className='text-3xl font-bold mb-4'>Welcome to YouthLink!</h1>
      <p className='text-lg'>This is the home page of the application. Feel free to explore and connect with mentors and peers on various topics!</p>
      <Link to='/messages' className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-4'>View Messages</Link>
    </div>
  );
}
export default HomePage;